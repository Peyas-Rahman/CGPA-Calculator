package com.example.cgpacalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText firstSemester;
    EditText secondSemester;
    EditText thirdSemester;
    EditText fourthSemester;
    EditText fifthSemester;
    EditText sixthSemester;
    EditText sevenSemester;
    EditText eightSemester;
    Button resultButton;
    TextView resultView;

    Button clearBtn;

    private double first;
    private double second;
    private double third;
    private double fourth;
    private double fifth;
    private double sixth;
    private double seven;
    private double eight;
    private double CGPA;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        setLayout();

        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClearText();
            }
        });

        resultButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
                ClearText();

            }
        });

    }



    private  void setLayout()
    {
        firstSemester = findViewById(R.id.firstSemesterEditText);
        secondSemester = findViewById(R.id.secondSemesterEditText);
        thirdSemester = findViewById(R.id.thirdSemesterEditText);
        fourthSemester = findViewById(R.id.fourthSemesterEditText);
        fifthSemester = findViewById(R.id.fifthSemesterEditText);
        sixthSemester = findViewById(R.id.sixthSemesterEditText);
        sevenSemester = findViewById(R.id.sevenSemesterEditText);
        eightSemester = findViewById(R.id.eightSemesterEditText);

        resultButton = findViewById(R.id.btnCalculate);
        resultView = findViewById(R.id.resultTextView);

        clearBtn = findViewById(R.id.btnClear);
    }

    private void calculate()
    {
        first = Double.parseDouble(firstSemester.getText().toString());
        second = Double.parseDouble(secondSemester.getText().toString());
        third = Double.parseDouble(thirdSemester.getText().toString());
        fourth = Double.parseDouble(fourthSemester.getText().toString());
        fifth = Double.parseDouble(fifthSemester.getText().toString());
        sixth = Double.parseDouble(sixthSemester.getText().toString());
        seven = Double.parseDouble(sevenSemester.getText().toString());
        eight = Double.parseDouble(eightSemester.getText().toString());

        CGPA = ((first*5) + (second*5) + (third*5) + (fourth * 15) + (fifth * 15) + (sixth * 20) + (seven * 25) + (eight * 10)) / 100;


        double f = Double.valueOf(CGPA);
        String test = String.format("%.02f", f);

        resultView.setText("Result Is : "+test);

    }

    private  void ClearText()
    {
        firstSemester.getText().clear();
        secondSemester.getText().clear();
        thirdSemester.getText().clear();
        fourthSemester.getText().clear();
        fifthSemester.getText().clear();
        sixthSemester.getText().clear();
        sevenSemester.getText().clear();
        eightSemester.getText().clear();
    }

}
